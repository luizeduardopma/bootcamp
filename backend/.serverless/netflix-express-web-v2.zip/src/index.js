"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ENV_VARS = exports.handler = void 0;
const dotenv_1 = __importDefault(require("dotenv"));
const express_1 = __importDefault(require("express"));
const mongoose_1 = __importDefault(require("mongoose"));
const cors_1 = __importDefault(require("cors"));
const serverless_http_1 = __importDefault(require("serverless-http"));
const api_routes_1 = require("./routes/api.routes");
const external_routes_1 = require("./routes/external.routes");
// TOKEN LUIZ -> eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjYxYmE4NDRkMzc3ZWYxMzVmZGVjNzM5YSIsImlhdCI6MTYzOTYxMzk0MCwiZXhwIjoxNjM5NzAwMzQwfQ.EvYbN7hJvkORRszkAx1N0LHY0ab85bcsnMKCTtQZGu8
// TOKEN LUIZ9 -> eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjYxYjdkNmE1YjEzZmY5YjRjODc0NjY4NyIsImlhdCI6MTYzOTYxMzk2OSwiZXhwIjoxNjM5NzAwMzY5fQ.8VIWkDDMRxy_UqGY6XdjrDB-XC7pM1V7-mEifv2bKVA
dotenv_1.default.config();
const ENV_VARS = {
    // port: process.env.PORT,
    mongoURI: process.env.MONGO_URI,
    TOKEN_SECRET: process.env.TOKEN_SECRET,
};
exports.ENV_VARS = ENV_VARS;
const app = (0, express_1.default)();
app.use(express_1.default.json());
app.use((0, cors_1.default)());
app.use(api_routes_1.apiRouter);
app.use(external_routes_1.extRouter);
// app.listen(ENV_VARS.port, async () => {
//   console.log("Server Funcionando na porta: ", ENV_VARS.port);
//   if (ENV_VARS.mongoURI) {
//     mongoose.connect(ENV_VARS.mongoURI);
//     console.log("DB conectada");
//   } else {
//     console.log("Erro ao conectar a DB");
//   }
// });
mongoose_1.default.connect(ENV_VARS.mongoURI);
exports.handler = (0, serverless_http_1.default)(app, {
    callbackWaitsForEmptyEventLoop: false,
});
